# Blood-Link
This web application connects blood donors, hospitals, and patients to ensure timely access to life-saving blood. It features a user-friendly interface where donors can register, track their donation history, and respond to emergency blood requests from hospitals
